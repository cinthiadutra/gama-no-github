# Formulários com Flutter

A branch master desse repositório é o código inicial para começarmos o curso de criação de formulários com Flutter da Alura!

## Aulas

Cada aula está organizada em uma branch :fire:, conforme você avançar nas aulas pode consultar branch por branch.

Bom estudo! :)
