# Registro de Testes de Software

<span style="color:red">Pré-requisitos: <a href="7-Programação de Funcionalidades.md"> Programação de Funcionalidades</a></span>, <a href="10-Plano de Testes de Usabilidade.md"> Plano de Testes de Usabilidade</a>

Relatório com evidências dos testes e relatos dos usuários participantes, baseado em um plano de testes pré-definido.

> **Links Úteis**:
> - [Ferramentas deTestes de Usabilidade](https://www.usability.gov/how-to-and-tools/resources/templates.html)
