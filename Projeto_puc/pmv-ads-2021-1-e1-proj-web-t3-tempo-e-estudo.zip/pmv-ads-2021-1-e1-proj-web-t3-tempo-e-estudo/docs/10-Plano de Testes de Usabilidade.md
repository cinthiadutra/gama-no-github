# Plano de Testes de Usabilidade

<span style="color:red">Pré-requisitos: <a href="2-Especificação do Projeto.md"> Especificação do Projeto</a></span>, <a href="3-Projeto de Interface.md"> Projeto de Interface</a>

Planejamento de realização de testes com usuários definindo as operações que os usuários devem realizar.

> **Links Úteis**:
> - [Ferramentas deTestes de Usabilidade](https://www.usability.gov/how-to-and-tools/resources/templates.html)