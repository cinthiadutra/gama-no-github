function Login() {
  let username = document.getElementById("inputemail");
  let password = document.getElementById("inputPassword");
  username = username.value.toLowerCase();
  password = password.value.toLowerCase();
  if (username == "thaina@gmail.com" && password == "1234567") {
    window.location.href= './home.html';
  } else {
    alert("Usuário ou senha não conferem");
  }
}

function salvarFormulario(){
  var nome = document.getElementById("nome");
  var email = document.getElementById("email");
  var password = document.getElementById("senha");
  var telefone = document.getElementById("telefone");

var dados = JSON.parse( localStorage.getItem("dadosformulario"));

  if(dados == null){
    localStorage.setItem("dadosformulario","[]");
    dados = [];
  }

  // nome = nome.value.toLowerCase();
  // email = email.value.toLowerCase();
  // password = password.value.toLowerCase();
  // telefone = telefone.value.toLowerCase();
  // if (nome == "" && password == ""&& email =="" && telefone == "") {
  //   alert("Cadastro incompleto");
    
  // } else {
  //   window.location.href= './home.html';
var auxRegistro ={
nome: nome.value,
email: email.value,
senha: password.value,
celular: telefone.value,
}
dados.push(auxRegistro);
localStorage.setItem("dadosformulario", JSON.stringify(dados));
alert("Cadastro efetuado com sucesso")

 nome.value = "";
 email.value = "";
 password.value = "";
 telefone.value ="";
}

function cancelar(){
  window.location.href= './logar.html';
}

// function gerarPassword() {
//   var email = document.getElementById("email");
//   var password = Math.random().toString(36).slice(-10);

//   var dadoSenha = JSON.parse( localStorage.getItem("dadosformulariosenha"));
//   if(dadoSenha == null){
//     localStorage.setItem("dadosformulario","[]");
//     dados = [];
//   }
//   var auxSenha ={
//    senha: password.value,
//   }
//     dadoSenha.push(auxSenha);
//     localStorage.setItem.apply("dadoSenha", JSON.stringify.apply(dadoSenha));
//   alert("sua nova senha é " + password);
//   window.location.href= './logar.html';
  

// }
// function pegarPassword(){
 
  
   
//     var btnGetItem = document.querySelector('.btnGetItem')
  
    
//     function getLocalStorage(){
//       btnGetItem.addEventListener('click', () => {
//         console.log(localStorage.getItem("dadosformulario"))
//       })
//     }
  
  
   
//     getLocalStorage();
  
//   }());


