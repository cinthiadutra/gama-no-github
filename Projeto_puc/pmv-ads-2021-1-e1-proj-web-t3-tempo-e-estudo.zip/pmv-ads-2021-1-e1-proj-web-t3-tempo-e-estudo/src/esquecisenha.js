function alterarSenha(evento){
    evento.preventDefault();

    var pegarEmail = document.getElementById("email_cad").value;
    
    var dados2= localStorage.getItem("dadosformulario");
    
    console.log(dados2);
    
}

document.getElementById("senhaNew").addEventListener("click", alterarSenha);